# Google Meet Account Switcher

Quickly switch between multiple accounts in Google Meet
