export const accounts = [
	{
		displayName: 'Account 1',
		authuser: 0
	},
	{
		displayName: 'Account 2',
		authuser: 1
	},
	{
		displayName: 'Account 3',
		authuser: 2
	}
]
